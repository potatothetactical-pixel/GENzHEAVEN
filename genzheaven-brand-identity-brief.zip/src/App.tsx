import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { 
  Menu, X, Sparkles, Heart, ShoppingBag,
  ArrowRight, Play, MessageSquare, ChevronDown,
  Search, Zap, Award, Shield,
  Truck, RefreshCcw, CreditCard, CheckCircle, Copy, ExternalLink, Trash2, Plus, Minus,
  Bot, Send
} from 'lucide-react';

// Types
interface Product {
  name: string;
  price: number;
  originalPrice: number;
  category: string;
  image: string;
  tag: string;
  colors: string[];
}

interface CartItem extends Product {
  quantity: number;
  selectedColor: string;
}

// Loading Screen Component
const LoadingScreen = ({ onComplete }: { onComplete: () => void }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 100);
    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, y: -100 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
    >
      <div className="text-center">
        <motion.div
          className="text-6xl md:text-8xl font-display font-bold mb-8"
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <span className="metallic-text">GENzHEAVEN</span>
        </motion.div>
        
        <div className="w-64 h-1 bg-gray-900 rounded-full overflow-hidden mx-auto">
          <motion.div
            className="h-full bg-white"
            style={{ width: `${Math.min(progress, 100)}%` }}
          />
        </div>
        
        <motion.p
          className="mt-4 text-gray-600 font-body text-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          {progress < 30 ? "Loading..." : 
           progress < 60 ? "Preparing..." :
           progress < 90 ? "Almost there..." :
           "Welcome"}
        </motion.p>
      </div>
    </motion.div>
  );
};

// Cart Sidebar Component
const CartSidebar = ({ 
  isOpen, 
  onClose, 
  cart, 
  updateQuantity, 
  removeFromCart,
  onCheckout 
}: { 
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  updateQuantity: (index: number, delta: number) => void;
  removeFromCart: (index: number) => void;
  onCheckout: () => void;
}) => {
  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className="fixed inset-0 bg-black/80 z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-gray-950 z-50 border-l border-gray-800"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25 }}
          >
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-6 border-b border-gray-800">
                <h2 className="text-xl font-display font-bold text-white">Your Cart</h2>
                <button onClick={onClose} className="text-gray-400 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6">
                {cart.length === 0 ? (
                  <div className="text-center py-12">
                    <ShoppingBag size={48} className="text-gray-700 mx-auto mb-4" />
                    <p className="text-gray-500">Your cart is empty</p>
                    <button onClick={onClose} className="mt-4 text-white underline">
                      Continue Shopping
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {cart.map((item, index) => (
                      <motion.div
                        key={`${item.name}-${index}`}
                        className="flex gap-4 bg-gray-900 rounded-lg p-4"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                      >
                        <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded" />
                        <div className="flex-1">
                          <h4 className="text-white font-bold text-sm">{item.name}</h4>
                          <p className="text-gray-500 text-xs">${item.price}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <button
                              onClick={() => updateQuantity(index, -1)}
                              className="p-1 bg-gray-800 rounded hover:bg-gray-700"
                            >
                              <Minus size={14} className="text-white" />
                            </button>
                            <span className="text-white text-sm w-8 text-center">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(index, 1)}
                              className="p-1 bg-gray-800 rounded hover:bg-gray-700"
                            >
                              <Plus size={14} className="text-white" />
                            </button>
                            <button
                              onClick={() => removeFromCart(index)}
                              className="ml-auto p-1 text-red-500 hover:text-red-400"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-6 border-t border-gray-800">
                  <div className="flex justify-between mb-4">
                    <span className="text-gray-400">Subtotal</span>
                    <span className="text-white font-bold">${total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between mb-4">
                    <span className="text-gray-400">Shipping</span>
                    <span className="text-green-400">Free</span>
                  </div>
                  <div className="flex justify-between mb-6 text-lg">
                    <span className="text-white font-bold">Total</span>
                    <span className="text-white font-bold">${total.toFixed(2)}</span>
                  </div>
                  <motion.button
                    className="w-full bg-white text-black py-4 rounded-lg font-display font-bold hover:bg-gray-200 transition-colors"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={onCheckout}
                  >
                    Proceed to Checkout
                  </motion.button>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

// Checkout Modal Component
const CheckoutModal = ({
  isOpen,
  onClose,
  cart,
  total,
  onOrderComplete
}: {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  total: number;
  onOrderComplete: () => void;
}) => {
  const [step, setStep] = useState<'details' | 'payment' | 'confirm'>('details');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zip: '',
  });
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card'>('upi');
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [copied, setCopied] = useState(false);

  const upiId = '9301806216@fam';

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePayment = async () => {
    setIsProcessing(true);
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    setIsProcessing(false);
    setOrderComplete(true);
    
    // Save order to localStorage
    const orderId = `GENZ${Date.now().toString().slice(-6)}`;
    const newOrder = {
      id: orderId,
      customer: { ...formData },
      items: cart,
      total: total,
      status: 'pending' as const,
      paymentMethod: paymentMethod,
      paymentStatus: 'completed' as const,
      orderDate: new Date().toISOString(),
      upiId: paymentMethod === 'upi' ? upiId : undefined,
    };
    
    const existingOrders = JSON.parse(localStorage.getItem('genzheaven_orders') || '[]');
    localStorage.setItem('genzheaven_orders', JSON.stringify([...existingOrders, newOrder]));
    
    setTimeout(() => {
      onOrderComplete();
      onClose();
      setOrderComplete(false);
      setStep('details');
    }, 3000);
  };

  const handleupiPayment = () => {
    const upiUrl = `upi://pay?pa=${upiId}&pn=GENzHEAVEN&am=${total}&cu=INR`;
    window.location.href = upiUrl;
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          className="bg-gray-950 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-gray-800"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-800 sticky top-0 bg-gray-950">
            <h2 className="text-2xl font-display font-bold text-white">Checkout</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-white">
              <X size={24} />
            </button>
          </div>

          {orderComplete ? (
            <div className="p-12 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', damping: 15 }}
              >
                <CheckCircle size={80} className="text-green-500 mx-auto mb-6" />
              </motion.div>
              <h3 className="text-3xl font-display font-bold text-white mb-4">Order Confirmed!</h3>
              <p className="text-gray-400 mb-2">Thank you for your purchase</p>
              <p className="text-gray-500 text-sm">Order ID: #GENZ{Date.now().toString().slice(-6)}</p>
              <p className="text-gray-500 text-sm mt-4">A confirmation email has been sent to your email.</p>
            </div>
          ) : (
            <div className="p-6">
              {/* Progress Steps */}
              <div className="flex items-center justify-center mb-8">
                {['Details', 'Payment', 'Confirm'].map((label, i) => (
                  <div key={label} className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      step === label.toLowerCase() || 
                      (step === 'payment' && i === 0) ||
                      (step === 'confirm' && i < 2)
                        ? 'bg-white text-black'
                        : 'bg-gray-800 text-gray-500'
                    }`}>
                      {i + 1}
                    </div>
                    <span className={`ml-2 text-sm ${
                      step === label.toLowerCase() ? 'text-white' : 'text-gray-500'
                    }`}>{label}</span>
                    {i < 2 && <div className="w-12 h-px bg-gray-800 mx-4" />}
                  </div>
                ))}
              </div>

              {/* Step 1: Shipping Details */}
              {step === 'details' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <h3 className="text-xl font-bold text-white mb-6">Shipping Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Full Name</label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Email</label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
                        placeholder="john@example.com"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Phone</label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
                        placeholder="+91 98765 43210"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">City</label>
                      <input
                        type="text"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
                        placeholder="Mumbai"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-gray-400 text-sm mb-2">Address</label>
                      <input
                        type="text"
                        value={formData.address}
                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                        className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
                        placeholder="123 Street Name, Area"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">ZIP Code</label>
                      <input
                        type="text"
                        value={formData.zip}
                        onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                        className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
                        placeholder="400001"
                      />
                    </div>
                  </div>
                  <motion.button
                    className="w-full mt-6 bg-white text-black py-4 rounded-lg font-display font-bold hover:bg-gray-200 transition-colors"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setStep('payment')}
                    disabled={!formData.name || !formData.email || !formData.phone || !formData.address}
                  >
                    Continue to Payment
                  </motion.button>
                </motion.div>
              )}

              {/* Step 2: Payment */}
              {step === 'payment' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <h3 className="text-xl font-bold text-white mb-6">Payment Method</h3>
                  
                  {/* Order Summary */}
                  <div className="bg-gray-900 rounded-lg p-4 mb-6">
                    <h4 className="text-white font-bold mb-4">Order Summary</h4>
                    <div className="space-y-2 mb-4">
                      {cart.map((item, i) => (
                        <div key={i} className="flex justify-between text-sm">
                          <span className="text-gray-400">{item.name} x {item.quantity}</span>
                          <span className="text-white">${(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="border-t border-gray-800 pt-4 flex justify-between">
                      <span className="text-white font-bold">Total</span>
                      <span className="text-white font-bold">${total.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Payment Options */}
                  <div className="space-y-4 mb-6">
                    <button
                      onClick={() => setPaymentMethod('upi')}
                      className={`w-full p-4 rounded-lg border flex items-center gap-4 ${
                        paymentMethod === 'upi' 
                          ? 'border-white bg-gray-900' 
                          : 'border-gray-800 bg-gray-950'
                      }`}
                    >
                      <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                        <CreditCard size={24} className="text-white" />
                      </div>
                      <div className="text-left">
                        <p className="text-white font-bold">UPI Payment</p>
                        <p className="text-gray-500 text-sm">Pay using any UPI app</p>
                      </div>
                      {paymentMethod === 'upi' && (
                        <CheckCircle size={20} className="text-green-500 ml-auto" />
                      )}
                    </button>

                    <button
                      onClick={() => setPaymentMethod('card')}
                      className={`w-full p-4 rounded-lg border flex items-center gap-4 ${
                        paymentMethod === 'card' 
                          ? 'border-white bg-gray-900' 
                          : 'border-gray-800 bg-gray-950'
                      }`}
                    >
                      <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
                        <CreditCard size={24} className="text-white" />
                      </div>
                      <div className="text-left">
                        <p className="text-white font-bold">Credit/Debit Card</p>
                        <p className="text-gray-500 text-sm">Visa, Mastercard, etc.</p>
                      </div>
                      {paymentMethod === 'card' && (
                        <CheckCircle size={20} className="text-green-500 ml-auto" />
                      )}
                    </button>
                  </div>

                  {/* UPI Details */}
                  {paymentMethod === 'upi' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="bg-gray-900 rounded-lg p-6 mb-6"
                    >
                      <h4 className="text-white font-bold mb-4">UPI Payment Details</h4>
                      <div className="flex items-center gap-3 mb-4">
                        <div className="flex-1 bg-black rounded-lg px-4 py-3 font-mono text-white">
                          {upiId}
                        </div>
                        <button
                          onClick={handleCopyUpi}
                          className="p-3 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors"
                        >
                          {copied ? <CheckCircle size={20} className="text-green-500" /> : <Copy size={20} className="text-white" />}
                        </button>
                      </div>
                      {copied && (
                        <p className="text-green-500 text-sm mb-4">Copied to clipboard!</p>
                      )}
                      <p className="text-gray-400 text-sm mb-4">
                        Open any UPI app (Google Pay, PhonePe, Paytm, etc.) and send payment to the UPI ID above.
                      </p>
                      <div className="flex gap-3">
                        <motion.button
                          className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={handleupiPayment}
                        >
                          <ExternalLink size={18} /> Pay Now
                        </motion.button>
                        <motion.button
                          className="flex-1 bg-white text-black py-3 rounded-lg font-bold hover:bg-gray-200 transition-colors"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={handlePayment}
                        >
                          I've Made Payment
                        </motion.button>
                      </div>
                    </motion.div>
                  )}

                  {/* Card Payment Form */}
                  {paymentMethod === 'card' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="bg-gray-900 rounded-lg p-6 mb-6"
                    >
                      <h4 className="text-white font-bold mb-4">Card Details</h4>
                      <div className="space-y-4">
                        <input
                          type="text"
                          placeholder="Card Number"
                          className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
                        />
                        <div className="grid grid-cols-2 gap-4">
                          <input
                            type="text"
                            placeholder="MM/YY"
                            className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
                          />
                          <input
                            type="text"
                            placeholder="CVV"
                            className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
                          />
                        </div>
                      </div>
                    </motion.div>
                  )}

                  <div className="flex gap-4">
                    <motion.button
                      className="flex-1 border border-gray-700 text-white py-4 rounded-lg font-display font-bold hover:border-gray-500 transition-colors"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setStep('details')}
                    >
                      Back
                    </motion.button>
                    <motion.button
                      className="flex-1 bg-white text-black py-4 rounded-lg font-display font-bold hover:bg-gray-200 transition-colors"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handlePayment}
                      disabled={isProcessing}
                    >
                      {isProcessing ? 'Processing...' : `Pay $${total.toFixed(2)}`}
                    </motion.button>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Processing/Confirm */}
              {step === 'confirm' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="text-center py-12"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-16 h-16 border-4 border-gray-800 border-t-white rounded-full animate-spin mx-auto mb-6" />
                      <h3 className="text-2xl font-bold text-white mb-2">Processing Payment</h3>
                      <p className="text-gray-400">Please wait while we confirm your payment...</p>
                    </>
                  ) : (
                    <>
                      <CheckCircle size={80} className="text-green-500 mx-auto mb-6" />
                      <h3 className="text-2xl font-bold text-white mb-2">Payment Successful!</h3>
                      <p className="text-gray-400">Your order has been confirmed.</p>
                    </>
                  )}
                </motion.div>
              )}
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

// Navigation Component
const Navigation = ({ 
  cartCount, 
  onCartClick 
}: { 
  cartCount: number;
  onCartClick: () => void;
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'T-Shirts', href: '#t-shirts' },
    { name: 'Hoodies', href: '#hoodies' },
    { name: 'Bottoms', href: '#bottoms' },
    { name: 'Footwear', href: '#footwear' },
    { name: 'Outerwear', href: '#outerwear' },
    { name: 'Accessories', href: '#accessories' },
  ];

  return (
    <>
      <motion.nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          scrolled ? 'bg-black/90 backdrop-blur-md py-4' : 'py-6 bg-transparent'
        }`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5, delay: 2 }}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <motion.a
            href="#"
            className="text-2xl font-display font-bold tracking-wider"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="metallic-text">GENzHEAVEN</span>
          </motion.a>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link, i) => (
              <motion.a
                key={link.name}
                href={link.href}
                className="text-gray-400 hover:text-white font-body text-sm transition-colors"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 2.2 + i * 0.1 }}
                whileHover={{ y: -2 }}
              >
                {link.name}
              </motion.a>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-4">
            <motion.button
              className="p-2 text-gray-400 hover:text-white transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Search size={20} />
            </motion.button>
            <motion.button
              className="p-2 text-gray-400 hover:text-white transition-colors relative"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={onCartClick}
            >
              <ShoppingBag size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-white text-black text-xs rounded-full flex items-center justify-center font-bold">
                  {cartCount}
                </span>
              )}
            </motion.button>
          </div>

          <motion.button
            className="md:hidden text-white"
            onClick={() => setIsOpen(!isOpen)}
            whileTap={{ scale: 0.9 }}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </motion.button>
        </div>
      </motion.nav>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed inset-0 z-30 bg-black md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="flex flex-col items-center justify-center h-full gap-8">
              {navLinks.map((link, i) => (
                <motion.a
                  key={link.name}
                  href={link.href}
                  className="text-2xl font-display text-white"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  onClick={() => setIsOpen(false)}
                >
                  {link.name}
                </motion.a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

// Hero Section
const HeroSection = () => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 200]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }} />
      </div>

      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gray-900 rounded-full blur-3xl opacity-50" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gray-800 rounded-full blur-3xl opacity-30" />

      <div className="absolute inset-0 opacity-40">
        <img
          src="/images/hero-banner.jpg"
          alt="Hero Banner"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-black" />
      </div>

      <motion.div
        className="relative z-10 text-center px-6 max-w-5xl mx-auto"
        style={{ y, opacity }}
      >
        <motion.div
          className="inline-flex items-center gap-2 px-4 py-2 border border-gray-800 rounded-full mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.5 }}
        >
          <Sparkles size={16} className="text-gray-500" />
          <span className="text-sm font-body text-gray-400">
            New Collection Drop 2026
          </span>
        </motion.div>

        <motion.h1
          className="text-5xl md:text-7xl lg:text-8xl font-display font-bold mb-6 leading-tight"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.7, duration: 0.8 }}
        >
          <span className="metallic-text">Define Your</span>
          <br />
          <span className="metallic-text-silver">Style Legacy</span>
        </motion.h1>

        <motion.p
          className="text-lg md:text-xl text-gray-500 font-body max-w-2xl mx-auto mb-10"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 3, duration: 0.8 }}
        >
          Premium streetwear designed for the culture. 
          Limited drops. Unlimited style.
        </motion.p>

        <motion.div
          className="flex flex-col sm:flex-row gap-4 justify-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 3.3, duration: 0.8 }}
        >
          <motion.a
            href="#shop"
            className="bg-white text-black px-8 py-4 rounded-lg font-display font-bold text-lg flex items-center justify-center gap-2 hover:bg-gray-200 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Shop Now <ArrowRight size={20} />
          </motion.a>
          <motion.button
            className="border border-gray-700 text-white px-8 py-4 rounded-lg font-display font-bold text-lg flex items-center justify-center gap-2 hover:border-gray-500 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Play size={20} /> View Lookbook
          </motion.button>
        </motion.div>

        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20 pt-10 border-t border-gray-900"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 3.8 }}
        >
          {[
            { number: '50K+', label: 'Happy Customers' },
            { number: '100+', label: 'Unique Designs' },
            { number: '25+', label: 'Countries' },
            { number: '4.9', label: 'Average Rating' },
          ].map((stat) => (
            <motion.div
              key={stat.label}
              className="text-center"
              whileHover={{ scale: 1.05 }}
            >
              <div className="text-3xl md:text-4xl font-display font-bold text-white">
                {stat.number}
              </div>
              <div className="text-sm text-gray-600 font-body mt-1">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>

      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <ChevronDown size={32} className="text-gray-700" />
      </motion.div>
    </section>
  );
};

// Product Card Component
const ProductCard = ({ product, index, addToCart, selectedColor, onColorSelect }: {
  product: Product;
  index: number;
  addToCart: (product: Product, color: string) => void;
  selectedColor: string;
  onColorSelect: (color: string) => void;
}) => {
  return (
    <motion.div
      className="group"
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.05 }}
    >
      <div className="relative bg-gray-950 rounded-lg overflow-hidden mb-4 group/image">
        <img
          src={product.image}
          alt={product.name}
          className="aspect-square object-cover w-full h-full"
        />
        
        <div className="absolute top-3 left-3">
          <span className="px-2 py-1 bg-white text-black text-xs font-bold uppercase tracking-wider">
            {product.tag}
          </span>
        </div>
        
        <div className="absolute inset-0 bg-black/80 opacity-0 group-hover/image:opacity-100 transition-opacity flex items-center justify-center gap-3">
          <motion.button
            className="px-4 py-2 bg-white text-black text-sm font-bold rounded"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => addToCart(product, selectedColor || product.colors[0])}
          >
            Add to Cart
          </motion.button>
        </div>
      </div>
      
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs text-gray-600 font-body mb-1">{product.category}</p>
          <h3 className="text-lg font-display font-bold text-white mb-2">{product.name}</h3>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-white font-bold">${product.price}</span>
            <span className="text-gray-600 line-through text-sm">${product.originalPrice}</span>
          </div>
          <div className="flex gap-1 mb-3">
            {product.colors.map((color) => (
              <button
                key={color}
                onClick={() => onColorSelect(color)}
                className={`w-4 h-4 rounded-full border-2 ${
                  selectedColor === color ? 'border-white' : 'border-gray-700'
                } ${
                  color === 'black' ? 'bg-black' :
                  color === 'white' ? 'bg-white' :
                  color === 'gray' ? 'bg-gray-500' :
                  color === 'olive' ? 'bg-olive-700' :
                  color === 'khaki' ? 'bg-khaki-500' :
                  color === 'charcoal' ? 'bg-gray-800' :
                  color === 'navy' ? 'bg-navy-800' :
                  color === 'brown' ? 'bg-brown-700' :
                  'bg-gray-500'
                }`}
              />
            ))}
          </div>
        </div>
        <motion.button
          className="p-2 text-gray-400 hover:text-white transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Heart size={18} />
        </motion.button>
      </div>
    </motion.div>
  );
};

// Category Section Component
const CategorySection = ({ 
  title, 
  subtitle, 
  products, 
  addToCart,
  bgImage 
}: { 
  title: string;
  subtitle: string;
  products: Product[];
  addToCart: (product: Product, color: string) => void;
  bgImage?: string;
}) => {
  const [selectedColors, setSelectedColors] = useState<{[key: number]: string}>({});

  const handleColorSelect = (productIndex: number, color: string) => {
    setSelectedColors(prev => ({ ...prev, [productIndex]: color }));
  };

  return (
    <section id={title.toLowerCase()} className="py-24 px-6 bg-black relative overflow-hidden">
      {bgImage && (
        <div className="absolute inset-0 opacity-5">
          <img src={bgImage} alt="" className="w-full h-full object-cover" />
        </div>
      )}
      
      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-xs font-body text-gray-500 uppercase tracking-widest mb-4 block">
            {subtitle}
          </span>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4 metallic-text">
            {title}
          </h2>
          <p className="text-gray-500 font-body max-w-2xl mx-auto">
            Premium quality meets contemporary design. 
            Each piece crafted for the modern individual.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, i) => (
            <ProductCard
              key={product.name}
              product={product}
              index={i}
              addToCart={addToCart}
              selectedColor={selectedColors[i] || product.colors[0]}
              onColorSelect={(color) => handleColorSelect(i, color)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

// Featured Products Section
const FeaturedProducts = ({ addToCart }: { addToCart: (product: Product, color: string) => void }) => {
  const products: Product[] = [
    {
      name: 'Oversized Hoodie',
      price: 89,
      originalPrice: 120,
      category: 'Hoodies',
      image: '/images/hoodie.jpg',
      tag: 'Best Seller',
      colors: ['black', 'gray', 'white'],
    },
    {
      name: 'Cargo Pants Pro',
      price: 125,
      originalPrice: 160,
      category: 'Bottoms',
      image: '/images/cargo-pants.jpg',
      tag: 'New',
      colors: ['black', 'olive', 'khaki'],
    },
    {
      name: 'Graphic Tee Vol.3',
      price: 55,
      originalPrice: 75,
      category: 'Tees',
      image: '/images/graphic-tee.jpg',
      tag: 'Limited',
      colors: ['black', 'white'],
    },
    {
      name: 'Tech Vest',
      price: 180,
      originalPrice: 220,
      category: 'Outerwear',
      image: '/images/tech-vest.jpg',
      tag: 'Premium',
      colors: ['black', 'charcoal'],
    },
    {
      name: 'Utility Cap',
      price: 45,
      originalPrice: 60,
      category: 'Accessories',
      image: '/images/cap.jpg',
      tag: 'Hot',
      colors: ['black', 'navy', 'gray'],
    },
    {
      name: 'Crossbody Bag',
      price: 95,
      originalPrice: 130,
      category: 'Accessories',
      image: '/images/crossbody-bag.jpg',
      tag: 'New',
      colors: ['black', 'brown'],
    },
    {
      name: 'Chunky Sneakers',
      price: 210,
      originalPrice: 280,
      category: 'Footwear',
      image: '/images/sneakers.jpg',
      tag: 'Exclusive',
      colors: ['black', 'white'],
    },
    {
      name: 'Beanie Classic',
      price: 35,
      originalPrice: 50,
      category: 'Accessories',
      image: '/images/beanie.jpg',
      tag: 'Essential',
      colors: ['black', 'gray', 'navy'],
    },
  ];

  const [selectedColor, setSelectedColor] = useState<{[key: number]: string}>({});

  const handleAddToCart = (product: Product, index: number) => {
    const color = selectedColor[index] || product.colors[0];
    addToCart(product, color);
  };

  return (
    <section id="shop" className="py-24 px-6 bg-black">
      <div className="max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-xs font-body text-gray-500 uppercase tracking-widest mb-4 block">
            Featured Collection
          </span>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4 text-white">
            Latest Drops
          </h2>
          <p className="text-gray-500 font-body max-w-2xl mx-auto">
            Premium quality meets contemporary design. 
            Each piece crafted for the modern individual.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, i) => (
            <motion.div
              key={product.name}
              className="group"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
            >
              <div className="relative bg-gray-950 rounded-lg overflow-hidden mb-4 group/image">
                <img
                  src={product.image}
                  alt={product.name}
                  className="aspect-square object-cover w-full h-full"
                />
                
                <div className="absolute top-3 left-3">
                  <span className="px-2 py-1 bg-white text-black text-xs font-bold uppercase tracking-wider">
                    {product.tag}
                  </span>
                </div>
                
                <div className="absolute inset-0 bg-black/80 opacity-0 group-hover/image:opacity-100 transition-opacity flex items-center justify-center gap-3">
                  <motion.button
                    className="px-4 py-2 bg-white text-black text-sm font-bold rounded"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleAddToCart(product, i)}
                  >
                    Add to Cart
                  </motion.button>
                </div>
              </div>
              
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-gray-600 font-body mb-1">{product.category}</p>
                  <h3 className="text-lg font-display font-bold text-white mb-2">{product.name}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-white font-bold">${product.price}</span>
                    <span className="text-gray-600 line-through text-sm">${product.originalPrice}</span>
                  </div>
                  <div className="flex gap-1 mb-3">
                    {product.colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => setSelectedColor({ ...selectedColor, [i]: color })}
                        className={`w-4 h-4 rounded-full border-2 ${
                          selectedColor[i] === color ? 'border-white' : 'border-gray-700'
                        } ${
                          color === 'black' ? 'bg-black' :
                          color === 'white' ? 'bg-white' :
                          color === 'gray' ? 'bg-gray-500' :
                          color === 'olive' ? 'bg-olive-700' :
                          color === 'khaki' ? 'bg-khaki-500' :
                          color === 'charcoal' ? 'bg-gray-800' :
                          color === 'navy' ? 'bg-navy-800' :
                          color === 'brown' ? 'bg-brown-700' :
                          'bg-gray-500'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <motion.button
                  className="p-2 text-gray-400 hover:text-white transition-colors"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Heart size={18} />
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <motion.a
            href="#shop"
            className="border border-gray-700 text-white px-8 py-4 rounded-lg font-display font-bold inline-flex items-center gap-2 hover:border-white transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            View All Products <ArrowRight size={18} />
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
};

// Collections Section
const CollectionsSection = () => {
  const collections = [
    { name: 'Essentials', count: '24 Products', image: '/images/collection-essentials.jpg' },
    { name: 'Streetwear', count: '18 Products', image: '/images/hero-banner.jpg' },
    { name: 'Accessories', count: '32 Products', image: '/images/collection-essentials.jpg' },
    { name: 'Footwear', count: '12 Products', image: '/images/hero-banner.jpg' },
  ];

  return (
    <section id="collections" className="py-24 px-6 bg-black">
      <div className="max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-xs font-body text-gray-500 uppercase tracking-widest mb-4 block">
            Shop By Category
          </span>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4 text-white">
            Collections
          </h2>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {collections.map((collection, i) => (
            <motion.div
              key={collection.name}
              className="relative h-80 rounded-lg bg-gray-900 overflow-hidden group cursor-pointer"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ scale: 1.02 }}
            >
              <img
                src={collection.image}
                alt={collection.name}
                className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-70 transition-opacity"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-2xl font-display font-bold text-white mb-1">{collection.name}</h3>
                <p className="text-gray-400 text-sm">{collection.count}</p>
                <motion.div
                  className="mt-4 flex items-center gap-2 text-white text-sm font-bold"
                  initial={{ x: -10, opacity: 0 }}
                  whileInView={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  Explore <ArrowRight size={16} />
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// T-Shirts Section
const TShirtsSection = ({ addToCart }: { addToCart: (product: Product, color: string) => void }) => {
  const products: Product[] = [
    { name: 'Graphic Tee Vol.3', price: 55, originalPrice: 75, category: 'Tees', image: '/images/graphic-tee.jpg', tag: 'Limited', colors: ['black', 'white'] },
    { name: 'Logo Tee Classic', price: 45, originalPrice: 60, category: 'Tees', image: '/images/graphic-tee.jpg', tag: 'Best Seller', colors: ['black', 'white', 'gray'] },
    { name: 'Oversized Tee', price: 50, originalPrice: 65, category: 'Tees', image: '/images/graphic-tee.jpg', tag: 'New', colors: ['black', 'gray'] },
    { name: 'Vintage Print Tee', price: 58, originalPrice: 78, category: 'Tees', image: '/images/graphic-tee.jpg', tag: 'Hot', colors: ['black', 'white'] },
    { name: 'Minimal Tee', price: 42, originalPrice: 55, category: 'Tees', image: '/images/graphic-tee.jpg', tag: 'Essential', colors: ['black', 'white', 'gray'] },
    { name: 'Street Art Tee', price: 62, originalPrice: 82, category: 'Tees', image: '/images/graphic-tee.jpg', tag: 'Limited', colors: ['black', 'white'] },
    { name: 'Basic Tee Pack', price: 99, originalPrice: 130, category: 'Tees', image: '/images/graphic-tee.jpg', tag: 'Value', colors: ['black', 'white', 'gray'] },
    { name: 'Edition Tee', price: 68, originalPrice: 90, category: 'Tees', image: '/images/graphic-tee.jpg', tag: 'Exclusive', colors: ['black', 'white'] },
  ];

  return <CategorySection title="T-Shirts" subtitle="Premium Tees Collection" products={products} addToCart={addToCart} bgImage="/images/graphic-tee.jpg" />;
};

// Hoodies Section
const HoodiesSection = ({ addToCart }: { addToCart: (product: Product, color: string) => void }) => {
  const products: Product[] = [
    { name: 'Oversized Hoodie', price: 89, originalPrice: 120, category: 'Hoodies', image: '/images/hoodie.jpg', tag: 'Best Seller', colors: ['black', 'gray', 'white'] },
    { name: 'Zip-Up Hoodie', price: 95, originalPrice: 130, category: 'Hoodies', image: '/images/hoodie.jpg', tag: 'New', colors: ['black', 'charcoal'] },
    { name: 'Cropped Hoodie', price: 82, originalPrice: 110, category: 'Hoodies', image: '/images/hoodie.jpg', tag: 'Trending', colors: ['black', 'gray'] },
    { name: 'Graphic Hoodie', price: 98, originalPrice: 135, category: 'Hoodies', image: '/images/hoodie.jpg', tag: 'Limited', colors: ['black', 'white'] },
    { name: 'Essential Hoodie', price: 79, originalPrice: 105, category: 'Hoodies', image: '/images/hoodie.jpg', tag: 'Essential', colors: ['black', 'gray', 'white'] },
    { name: 'Tech Fleece Hoodie', price: 115, originalPrice: 155, category: 'Hoodies', image: '/images/hoodie.jpg', tag: 'Premium', colors: ['black', 'charcoal'] },
    { name: 'Pullover Hoodie', price: 85, originalPrice: 115, category: 'Hoodies', image: '/images/hoodie.jpg', tag: 'Classic', colors: ['black', 'gray'] },
    { name: 'Signature Hoodie', price: 105, originalPrice: 145, category: 'Hoodies', image: '/images/hoodie.jpg', tag: 'Exclusive', colors: ['black', 'white'] },
  ];

  return <CategorySection title="Hoodies" subtitle="Cozy & Stylish Hoodies" products={products} addToCart={addToCart} bgImage="/images/hoodie.jpg" />;
};

// Bottoms Section
const BottomsSection = ({ addToCart }: { addToCart: (product: Product, color: string) => void }) => {
  const products: Product[] = [
    { name: 'Cargo Pants Pro', price: 125, originalPrice: 160, category: 'Bottoms', image: '/images/cargo-pants.jpg', tag: 'New', colors: ['black', 'olive', 'khaki'] },
    { name: 'Slim Fit Jeans', price: 110, originalPrice: 145, category: 'Bottoms', image: '/images/cargo-pants.jpg', tag: 'Best Seller', colors: ['black', 'gray'] },
    { name: 'Joggers Elite', price: 95, originalPrice: 125, category: 'Bottoms', image: '/images/cargo-pants.jpg', tag: 'Comfort', colors: ['black', 'gray', 'navy'] },
    { name: 'Utility Shorts', price: 75, originalPrice: 95, category: 'Bottoms', image: '/images/cargo-pants.jpg', tag: 'Summer', colors: ['black', 'khaki', 'olive'] },
    { name: 'Track Pants', price: 88, originalPrice: 115, category: 'Bottoms', image: '/images/cargo-pants.jpg', tag: 'Sport', colors: ['black', 'gray'] },
    { name: 'Wide Leg Pants', price: 118, originalPrice: 155, category: 'Bottoms', image: '/images/cargo-pants.jpg', tag: 'Trending', colors: ['black', 'charcoal'] },
    { name: 'Tech Pants', price: 135, originalPrice: 175, category: 'Bottoms', image: '/images/cargo-pants.jpg', tag: 'Premium', colors: ['black', 'gray'] },
    { name: 'Classic Chinos', price: 98, originalPrice: 130, category: 'Bottoms', image: '/images/cargo-pants.jpg', tag: 'Essential', colors: ['black', 'khaki', 'navy'] },
  ];

  return <CategorySection title="Bottoms" subtitle="Pants, Jeans & Joggers" products={products} addToCart={addToCart} bgImage="/images/cargo-pants.jpg" />;
};

// Accessories Section
const AccessoriesSection = ({ addToCart }: { addToCart: (product: Product, color: string) => void }) => {
  const products: Product[] = [
    { name: 'Utility Cap', price: 45, originalPrice: 60, category: 'Accessories', image: '/images/cap.jpg', tag: 'Hot', colors: ['black', 'navy', 'gray'] },
    { name: 'Crossbody Bag', price: 95, originalPrice: 130, category: 'Accessories', image: '/images/crossbody-bag.jpg', tag: 'New', colors: ['black', 'brown'] },
    { name: 'Beanie Classic', price: 35, originalPrice: 50, category: 'Accessories', image: '/images/beanie.jpg', tag: 'Essential', colors: ['black', 'gray', 'navy'] },
    { name: 'Bucket Hat', price: 42, originalPrice: 55, category: 'Accessories', image: '/images/cap.jpg', tag: 'Trending', colors: ['black', 'gray'] },
    { name: 'Chain Necklace', price: 55, originalPrice: 75, category: 'Accessories', image: '/images/crossbody-bag.jpg', tag: 'Statement', colors: ['silver', 'gold'] },
    { name: 'Wrist Watch', price: 125, originalPrice: 165, category: 'Accessories', image: '/images/crossbody-bag.jpg', tag: 'Premium', colors: ['black', 'silver'] },
    { name: 'Sunglasses', price: 68, originalPrice: 90, category: 'Accessories', image: '/images/cap.jpg', tag: 'Summer', colors: ['black', 'tortoise'] },
    { name: 'Belt Leather', price: 58, originalPrice: 78, category: 'Accessories', image: '/images/crossbody-bag.jpg', tag: 'Classic', colors: ['black', 'brown'] },
  ];

  return <CategorySection title="Accessories" subtitle="Complete Your Look" products={products} addToCart={addToCart} bgImage="/images/cap.jpg" />;
};

// Footwear Section
const FootwearSection = ({ addToCart }: { addToCart: (product: Product, color: string) => void }) => {
  const products: Product[] = [
    { name: 'Chunky Sneakers', price: 210, originalPrice: 280, category: 'Footwear', image: '/images/sneakers.jpg', tag: 'Exclusive', colors: ['black', 'white'] },
    { name: 'Low Top Sneakers', price: 185, originalPrice: 245, category: 'Footwear', image: '/images/sneakers.jpg', tag: 'Best Seller', colors: ['black', 'white', 'gray'] },
    { name: 'High Top Sneakers', price: 195, originalPrice: 260, category: 'Footwear', image: '/images/sneakers.jpg', tag: 'Classic', colors: ['black', 'white'] },
    { name: 'Running Shoes', price: 175, originalPrice: 230, category: 'Footwear', image: '/images/sneakers.jpg', tag: 'Sport', colors: ['black', 'gray'] },
    { name: 'Slip-On Shoes', price: 145, originalPrice: 190, category: 'Footwear', image: '/images/sneakers.jpg', tag: 'Easy', colors: ['black', 'white'] },
    { name: 'Combat Boots', price: 225, originalPrice: 295, category: 'Footwear', image: '/images/sneakers.jpg', tag: 'Edgy', colors: ['black', 'brown'] },
    { name: 'Canvas Shoes', price: 125, originalPrice: 165, category: 'Footwear', image: '/images/sneakers.jpg', tag: 'Casual', colors: ['black', 'white', 'gray'] },
    { name: 'Limited Edition', price: 285, originalPrice: 375, category: 'Footwear', image: '/images/sneakers.jpg', tag: 'Rare', colors: ['black', 'white'] },
  ];

  return <CategorySection title="Footwear" subtitle="Sneakers & Boots" products={products} addToCart={addToCart} bgImage="/images/sneakers.jpg" />;
};

// Outerwear Section
const OuterwearSection = ({ addToCart }: { addToCart: (product: Product, color: string) => void }) => {
  const products: Product[] = [
    { name: 'Tech Vest', price: 180, originalPrice: 220, category: 'Outerwear', image: '/images/tech-vest.jpg', tag: 'Premium', colors: ['black', 'charcoal'] },
    { name: 'Bomber Jacket', price: 195, originalPrice: 260, category: 'Outerwear', image: '/images/tech-vest.jpg', tag: 'Classic', colors: ['black', 'navy'] },
    { name: 'Denim Jacket', price: 165, originalPrice: 220, category: 'Outerwear', image: '/images/tech-vest.jpg', tag: 'Vintage', colors: ['black', 'gray'] },
    { name: 'Windbreaker', price: 145, originalPrice: 190, category: 'Outerwear', image: '/images/tech-vest.jpg', tag: 'Lightweight', colors: ['black', 'gray'] },
    { name: 'Puffer Jacket', price: 225, originalPrice: 295, category: 'Outerwear', image: '/images/tech-vest.jpg', tag: 'Winter', colors: ['black', 'charcoal'] },
    { name: 'Leather Jacket', price: 285, originalPrice: 375, category: 'Outerwear', image: '/images/tech-vest.jpg', tag: 'Luxury', colors: ['black', 'brown'] },
    { name: 'Track Jacket', price: 135, originalPrice: 175, category: 'Outerwear', image: '/images/tech-vest.jpg', tag: 'Sport', colors: ['black', 'gray', 'navy'] },
    { name: 'Trench Coat', price: 245, originalPrice: 325, category: 'Outerwear', image: '/images/tech-vest.jpg', tag: 'Elegant', colors: ['black', 'charcoal'] },
  ];

  return <CategorySection title="Outerwear" subtitle="Jackets & Vests" products={products} addToCart={addToCart} bgImage="/images/tech-vest.jpg" />;
};

// Features Section
const FeaturesSection = () => {
  const features = [
    { icon: Truck, title: 'Free Shipping', description: 'On orders over $150' },
    { icon: RefreshCcw, title: 'Easy Returns', description: '30-day return policy' },
    { icon: Shield, title: 'Secure Payment', description: '100% secure checkout' },
    { icon: Award, title: 'Premium Quality', description: 'Crafted with care' },
  ];

  return (
    <section className="py-16 px-6 bg-black border-y border-gray-900">
      <div className="max-w-7xl mx-auto">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              className="flex items-center gap-4"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <div className="w-12 h-12 bg-gray-900 rounded-lg flex items-center justify-center">
                <feature.icon size={24} className="text-gray-400" />
              </div>
              <div>
                <h4 className="text-white font-display font-bold">{feature.title}</h4>
                <p className="text-gray-600 text-sm font-body">{feature.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Footer Component
const Footer = () => {
  const footerLinks = {
    Shop: ['All Products', 'New Arrivals', 'Best Sellers', 'Sale'],
    Help: ['Shipping', 'Returns', 'FAQ', 'Contact Us'],
    Company: ['About Us', 'Careers', 'Press', 'Stores'],
    Social: ['Instagram', 'Twitter', 'Youtube', 'TikTok'],
  };

  return (
    <footer className="py-16 px-6 bg-black border-t border-gray-900">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-5 gap-12 mb-12">
          <div className="md:col-span-2">
            <a href="#" className="text-3xl font-display font-bold tracking-wider mb-4 block">
              <span className="metallic-text">GENzHEAVEN</span>
            </a>
            <p className="text-gray-500 font-body mb-6 max-w-sm">
              Premium streetwear for the culture. 
              Designed for those who dare to stand out.
            </p>
            <div className="flex items-center gap-4">
              {[Sparkles, Heart, Zap, MessageSquare].map((Icon, index) => (
                <motion.a
                  key={index}
                  href="#"
                  className="p-3 bg-gray-900 rounded-full text-gray-500 hover:text-white hover:bg-gray-800 transition-all"
                  whileHover={{ scale: 1.1, y: -2 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Icon size={18} />
                </motion.a>
              ))}
            </div>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="font-display font-bold text-white mb-4">{category}</h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-gray-500 hover:text-white font-body text-sm transition-colors"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="pt-8 border-t border-gray-900 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-700 text-sm font-body">
            © 2026 GENzHEAVEN. All rights reserved.
          </p>
          <div className="flex items-center gap-6 text-gray-700 text-sm">
            <a href="#" className="hover:text-gray-500 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-gray-500 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-gray-500 transition-colors">Cookie Policy</a>
            <a href="#/admin" className="hover:text-gray-500 transition-colors opacity-30 hover:opacity-100">Admin</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// AI Helper Component
const AIHelper = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{text: string; isBot: boolean; timestamp: Date}[]>([
    { text: "Hey! I'm your GENzHEAVEN assistant. How can I help you today?", isBot: true, timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const quickQuestions = [
    "Where's my order?",
    "What's the return policy?",
    "Do you ship internationally?",
    "How do I track my order?",
    "What payment methods do you accept?",
  ];

  const botResponses: {[key: string]: string} = {
    "where": "You can track your order by checking your email for the tracking number, or visit the 'Help' section and enter your order ID. Orders typically ship within 2-3 business days.",
    "return": "We offer a 30-day return policy. Items must be unworn, unwashed, and in original packaging. Initiate returns from your account or contact support.",
    "ship": "Yes! We ship worldwide. Free shipping on orders over $150. International shipping takes 7-14 business days.",
    "track": "Once your order ships, you'll receive a tracking number via email. You can also check order status in your account dashboard.",
    "payment": "We accept all major credit cards, debit cards, and UPI payments (Google Pay, PhonePe, Paytm). All transactions are secure.",
    "size": "Check our size guide on each product page. If you're between sizes, we recommend sizing up for a relaxed fit.",
    "discount": "Sign up for our newsletter to get 10% off your first order. We also run seasonal sales and exclusive member discounts.",
    "contact": "You can reach us at support@genzheaven.com or through the contact form in the Help section. We respond within 24 hours.",
    "hello": "Hey there! 👋 Ready to find your perfect style? Ask me anything about our products, shipping, or policies!",
    "hi": "Hello! Welcome to GENzHEAVEN! How can I assist you with your shopping today?",
    "help": "I'm here to help! You can ask me about orders, returns, shipping, sizing, payments, or anything else!",
  };

  const getBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    for (const [key, response] of Object.entries(botResponses)) {
      if (lowerMessage.includes(key)) {
        return response;
      }
    }
    
    if (lowerMessage.includes("hoodie") || lowerMessage.includes("shirt") || lowerMessage.includes("pant")) {
      return "Great choice! Our products are made from premium materials. Check the product page for detailed descriptions, size charts, and customer reviews. Need help with sizing?";
    }
    
    if (lowerMessage.includes("price") || lowerMessage.includes("cost") || lowerMessage.includes("expensive")) {
      return "We offer premium quality at competitive prices. Plus, we have regular sales and a rewards program! Sign up for 10% off your first order.";
    }
    
    if (lowerMessage.includes("color") || lowerMessage.includes("black") || lowerMessage.includes("white")) {
      return "Each product shows available colors as swatches on the product page. Click on a color to see that variant. Some items are limited edition!";
    }
    
    return "Thanks for your message! For specific inquiries, please contact support@genzheaven.com. In the meantime, browse our latest drops in the Shop section!";
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setMessages(prev => [...prev, { text: userMessage, isBot: false, timestamp: new Date() }]);
    setInput('');
    setIsTyping(true);

    // Simulate bot thinking
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));

    const botResponse = getBotResponse(userMessage);
    setMessages(prev => [...prev, { text: botResponse, isBot: true, timestamp: new Date() }]);
    setIsTyping(false);
  };

  const handleQuickQuestion = (question: string) => {
    setInput(question);
  };

  return (
    <>
      {/* Floating Chat Button */}
      <motion.button
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-200 transition-colors"
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 4, type: 'spring' }}
      >
        {isOpen ? (
          <X size={24} className="text-black" />
        ) : (
          <Bot size={24} className="text-black" />
        )}
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed bottom-24 right-6 z-50 w-80 md:w-96 bg-gray-950 rounded-2xl border border-gray-800 shadow-2xl overflow-hidden"
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-gray-900 to-gray-800 p-4 border-b border-gray-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                  <Bot size={20} className="text-black" />
                </div>
                <div>
                  <h3 className="text-white font-bold">GENzHEAVEN Assistant</h3>
                  <p className="text-green-500 text-xs flex items-center gap-1">
                    <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                    Online
                  </p>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="h-80 overflow-y-auto p-4 space-y-4">
              {messages.map((message, index) => (
                <motion.div
                  key={index}
                  className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-2xl ${
                      message.isBot
                        ? 'bg-gray-900 text-gray-300 rounded-bl-none'
                        : 'bg-white text-black rounded-br-none'
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                    <p className="text-xs opacity-50 mt-1">
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </motion.div>
              ))}
              {isTyping && (
                <motion.div
                  className="flex justify-start"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <div className="bg-gray-900 p-3 rounded-2xl rounded-bl-none">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Quick Questions */}
            <div className="px-4 py-2 border-t border-gray-800">
              <div className="flex flex-wrap gap-2">
                {quickQuestions.slice(0, 3).map((question, i) => (
                  <button
                    key={i}
                    onClick={() => handleQuickQuestion(question)}
                    className="px-3 py-1 bg-gray-900 text-gray-400 text-xs rounded-full hover:bg-gray-800 hover:text-white transition-colors"
                  >
                    {question}
                  </button>
                ))}
              </div>
            </div>

            {/* Input */}
            <div className="p-4 border-t border-gray-800">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask me anything..."
                  className="flex-1 bg-gray-900 border border-gray-800 rounded-full px-4 py-2 text-white text-sm focus:outline-none focus:border-gray-600"
                />
                <motion.button
                  onClick={handleSend}
                  className="p-2 bg-white rounded-full hover:bg-gray-200 transition-colors"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Send size={18} className="text-black" />
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

// Main App Component
export default function App() {
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  const addToCart = (product: Product, selectedColor: string) => {
    setCart(prev => {
      const existing = prev.findIndex(
        item => item.name === product.name && item.selectedColor === selectedColor
      );
      if (existing >= 0) {
        const updated = [...prev];
        updated[existing].quantity += 1;
        return updated;
      }
      return [...prev, { ...product, quantity: 1, selectedColor }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (index: number, delta: number) => {
    setCart(prev => {
      const updated = [...prev];
      updated[index].quantity += delta;
      if (updated[index].quantity <= 0) {
        updated.splice(index, 1);
      }
      return updated;
    });
  };

  const removeFromCart = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOrderComplete = () => {
    setCart([]);
    setIsCheckoutOpen(false);
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-black text-white">
      <AnimatePresence>
        {loading && <LoadingScreen onComplete={() => setLoading(false)} />}
      </AnimatePresence>

      {!loading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Navigation cartCount={cartCount} onCartClick={() => setIsCartOpen(true)} />
          
          <CartSidebar
            isOpen={isCartOpen}
            onClose={() => setIsCartOpen(false)}
            cart={cart}
            updateQuantity={updateQuantity}
            removeFromCart={removeFromCart}
            onCheckout={handleCheckout}
          />

          <CheckoutModal
            isOpen={isCheckoutOpen}
            onClose={() => setIsCheckoutOpen(false)}
            cart={cart}
            total={cartTotal}
            onOrderComplete={handleOrderComplete}
          />

          <main>
            <HeroSection />
            <FeaturesSection />
            <FeaturedProducts addToCart={addToCart} />
            <CollectionsSection />
            <TShirtsSection addToCart={addToCart} />
            <HoodiesSection addToCart={addToCart} />
            <BottomsSection addToCart={addToCart} />
            <FootwearSection addToCart={addToCart} />
            <OuterwearSection addToCart={addToCart} />
            <AccessoriesSection addToCart={addToCart} />
          </main>
          <Footer />
          <AIHelper />
        </motion.div>
      )}
    </div>
  );
}
