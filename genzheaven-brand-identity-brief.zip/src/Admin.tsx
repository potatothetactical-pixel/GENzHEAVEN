import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Package, Users, DollarSign, TrendingUp, Search, Filter,
  Eye, X, CheckCircle, Clock, AlertCircle, LogOut, Shield,
  MapPin, CreditCard, Copy, RefreshCcw
} from 'lucide-react';

// Types
interface OrderItem {
  name: string;
  price: number;
  quantity: number;
  selectedColor: string;
  image: string;
}

interface Order {
  id: string;
  customer: {
    name: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    zip: string;
  };
  items: OrderItem[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  paymentMethod: 'upi' | 'card';
  paymentStatus: 'pending' | 'completed' | 'failed';
  orderDate: string;
  upiId?: string;
}

// Admin Login Component
const AdminLogin = ({ onLogin }: { onLogin: () => void }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simple password check (in production, use proper auth)
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (password === 'admin123' || password === 'GENzHEAVEN') {
      localStorage.setItem('adminAuthenticated', 'true');
      onLogin();
    } else {
      setError('Invalid password. Please try again.');
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <motion.div
        className="w-full max-w-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="bg-gray-950 rounded-2xl p-8 border border-gray-800">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield size={32} className="text-white" />
            </div>
            <h1 className="text-3xl font-display font-bold text-white mb-2">
              <span className="metallic-text">GENzHEAVEN</span>
            </h1>
            <p className="text-gray-500">Admin Access</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-gray-400 text-sm mb-2">
                Admin Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
                placeholder="Enter password"
              />
              {error && (
                <p className="text-red-500 text-sm mt-2 flex items-center gap-2">
                  <AlertCircle size={14} /> {error}
                </p>
              )}
            </div>

            <motion.button
              type="submit"
              className="w-full bg-white text-black py-3 rounded-lg font-display font-bold hover:bg-gray-200 transition-colors"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              disabled={isLoading}
            >
              {isLoading ? 'Authenticating...' : 'Login'}
            </motion.button>
          </form>

          <p className="text-gray-600 text-xs text-center mt-6">
            Protected area. Authorized personnel only.
          </p>
        </div>
      </motion.div>
    </div>
  );
};

// Order Detail Modal
const OrderDetailModal = ({ 
  order, 
  onClose,
  onUpdateStatus 
}: { 
  order: Order;
  onClose: () => void;
  onUpdateStatus: (orderId: string, status: Order['status']) => void;
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const statusColors = {
    pending: 'bg-yellow-500/20 text-yellow-500',
    processing: 'bg-blue-500/20 text-blue-500',
    shipped: 'bg-purple-500/20 text-purple-500',
    delivered: 'bg-green-500/20 text-green-500',
    cancelled: 'bg-red-500/20 text-red-500',
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <motion.div
          className="bg-gray-950 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto border border-gray-800"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="sticky top-0 bg-gray-950 border-b border-gray-800 p-6 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-display font-bold text-white">Order Details</h2>
              <p className="text-gray-500 text-sm">#{order.id}</p>
            </div>
            <button onClick={onClose} className="text-gray-400 hover:text-white">
              <X size={24} />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {/* Status Badge */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className={`px-4 py-2 rounded-full text-sm font-bold ${statusColors[order.status]}`}>
                  {order.status.toUpperCase()}
                </span>
                <span className={`px-4 py-2 rounded-full text-sm font-bold ${
                  order.paymentStatus === 'completed' 
                    ? 'bg-green-500/20 text-green-500' 
                    : order.paymentStatus === 'pending'
                    ? 'bg-yellow-500/20 text-yellow-500'
                    : 'bg-red-500/20 text-red-500'
                }`}>
                  Payment: {order.paymentStatus.toUpperCase()}
                </span>
              </div>
              <span className="text-gray-500 text-sm">
                {new Date(order.orderDate).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </span>
            </div>

            {/* Customer Info */}
            <div className="bg-gray-900 rounded-lg p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Users size={20} className="text-gray-400" />
                Customer Information
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-500 text-sm">Full Name</p>
                  <p className="text-white font-medium">{order.customer.name}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-sm">Email</p>
                  <div className="flex items-center gap-2">
                    <p className="text-white font-medium">{order.customer.email}</p>
                    <button 
                      onClick={() => handleCopy(order.customer.email)}
                      className="text-gray-500 hover:text-white"
                    >
                      {copied ? <CheckCircle size={14} className="text-green-500" /> : <Copy size={14} />}
                    </button>
                  </div>
                </div>
                <div>
                  <p className="text-gray-500 text-sm">Phone</p>
                  <p className="text-white font-medium">{order.customer.phone}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-sm">Payment Method</p>
                  <p className="text-white font-medium flex items-center gap-2">
                    <CreditCard size={14} />
                    {order.paymentMethod.toUpperCase()}
                  </p>
                </div>
                <div className="md:col-span-2">
                  <p className="text-gray-500 text-sm">Shipping Address</p>
                  <p className="text-white font-medium flex items-start gap-2">
                    <MapPin size={14} className="mt-1 flex-shrink-0" />
                    {order.customer.address}, {order.customer.city} - {order.customer.zip}
                  </p>
                </div>
              </div>
            </div>

            {/* Order Items */}
            <div className="bg-gray-900 rounded-lg p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Package size={20} className="text-gray-400" />
                Order Items ({order.items.length})
              </h3>
              <div className="space-y-4">
                {order.items.map((item, index) => (
                  <div key={index} className="flex items-center gap-4 bg-gray-950 rounded-lg p-4">
                    <img 
                      src={item.image} 
                      alt={item.name} 
                      className="w-20 h-20 object-cover rounded"
                    />
                    <div className="flex-1">
                      <h4 className="text-white font-bold">{item.name}</h4>
                      <p className="text-gray-500 text-sm">Color: {item.selectedColor}</p>
                      <p className="text-gray-500 text-sm">Quantity: {item.quantity}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-bold">${(item.price * item.quantity).toFixed(2)}</p>
                      <p className="text-gray-500 text-sm">${item.price} each</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="bg-gray-900 rounded-lg p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <DollarSign size={20} className="text-gray-400" />
                Order Summary
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between text-gray-400">
                  <span>Subtotal</span>
                  <span>${order.total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Shipping</span>
                  <span className="text-green-500">Free</span>
                </div>
                <div className="border-t border-gray-800 pt-3 flex justify-between text-lg">
                  <span className="text-white font-bold">Total</span>
                  <span className="text-white font-bold">${order.total.toFixed(2)}</span>
                </div>
              </div>
              {order.upiId && (
                <div className="mt-4 pt-4 border-t border-gray-800">
                  <p className="text-gray-500 text-sm mb-1">UPI ID Used</p>
                  <p className="text-white font-mono">{order.upiId}</p>
                </div>
              )}
            </div>

            {/* Update Status */}
            <div className="bg-gray-900 rounded-lg p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <RefreshCcw size={20} className="text-gray-400" />
                Update Order Status
              </h3>
              <div className="flex flex-wrap gap-2">
                {(['pending', 'processing', 'shipped', 'delivered', 'cancelled'] as const).map((status) => (
                  <button
                    key={status}
                    onClick={() => onUpdateStatus(order.id, status)}
                    className={`px-4 py-2 rounded-lg text-sm font-bold transition-colors ${
                      order.status === status
                        ? 'bg-white text-black'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

// Admin Dashboard Component
const AdminDashboard = ({ onLogout }: { onLogout: () => void }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [stats, setStats] = useState({
    totalOrders: 0,
    totalRevenue: 0,
    pendingOrders: 0,
    completedOrders: 0,
  });

  useEffect(() => {
    loadOrders();
  }, []);

  useEffect(() => {
    filterOrders();
  }, [orders, searchTerm, statusFilter]);

  useEffect(() => {
    calculateStats();
  }, [orders]);

  const loadOrders = () => {
    const savedOrders = localStorage.getItem('genzheaven_orders');
    if (savedOrders) {
      const parsedOrders = JSON.parse(savedOrders);
      setOrders(parsedOrders);
    }
  };

  const filterOrders = () => {
    let filtered = [...orders];

    if (searchTerm) {
      filtered = filtered.filter(order =>
        order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(order => order.status === statusFilter);
    }

    setFilteredOrders(filtered);
  };

  const calculateStats = () => {
    setStats({
      totalOrders: orders.length,
      totalRevenue: orders.reduce((sum, order) => sum + order.total, 0),
      pendingOrders: orders.filter(o => o.status === 'pending' || o.status === 'processing').length,
      completedOrders: orders.filter(o => o.status === 'delivered').length,
    });
  };

  const updateOrderStatus = (orderId: string, newStatus: Order['status']) => {
    const updatedOrders = orders.map(order =>
      order.id === orderId ? { ...order, status: newStatus } : order
    );
    setOrders(updatedOrders);
    localStorage.setItem('genzheaven_orders', JSON.stringify(updatedOrders));
    setSelectedOrder(null);
  };

  const exportOrders = () => {
    const csvContent = [
      ['Order ID', 'Customer', 'Email', 'Phone', 'Total', 'Status', 'Payment', 'Date'].join(','),
      ...orders.map(order => [
        order.id,
        order.customer.name,
        order.customer.email,
        order.customer.phone,
        order.total,
        order.status,
        order.paymentStatus,
        order.orderDate
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `orders-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const statusColors = {
    pending: 'bg-yellow-500/20 text-yellow-500',
    processing: 'bg-blue-500/20 text-blue-500',
    shipped: 'bg-purple-500/20 text-purple-500',
    delivered: 'bg-green-500/20 text-green-500',
    cancelled: 'bg-red-500/20 text-red-500',
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="border-b border-gray-800 sticky top-0 bg-black/95 backdrop-blur-md z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Shield size={24} className="text-white" />
            <div>
              <h1 className="text-xl font-display font-bold text-white">
                <span className="metallic-text">GENzHEAVEN</span>
              </h1>
              <p className="text-gray-500 text-xs">Admin Dashboard</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <motion.button
              onClick={exportOrders}
              className="px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-bold hover:bg-gray-800 transition-colors"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Export CSV
            </motion.button>
            <motion.button
              onClick={onLogout}
              className="px-4 py-2 bg-red-500/20 text-red-500 rounded-lg text-sm font-bold hover:bg-red-500/30 transition-colors flex items-center gap-2"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <LogOut size={16} /> Logout
            </motion.button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <motion.div
            className="bg-gray-950 rounded-xl p-6 border border-gray-800"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center justify-between mb-4">
              <Package size={24} className="text-blue-500" />
              <TrendingUp size={20} className="text-green-500" />
            </div>
            <p className="text-gray-500 text-sm mb-1">Total Orders</p>
            <p className="text-3xl font-display font-bold metallic-text">{stats.totalOrders}</p>
          </motion.div>

          <motion.div
            className="bg-gray-950 rounded-xl p-6 border border-gray-800"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="flex items-center justify-between mb-4">
              <DollarSign size={24} className="text-gray-400" />
              <TrendingUp size={20} className="text-gray-500" />
            </div>
            <p className="text-gray-500 text-sm mb-1">Total Revenue</p>
            <p className="text-3xl font-display font-bold metallic-text">${stats.totalRevenue.toFixed(2)}</p>
          </motion.div>

          <motion.div
            className="bg-gray-950 rounded-xl p-6 border border-gray-800"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center justify-between mb-4">
              <Clock size={24} className="text-gray-400" />
              <TrendingUp size={20} className="text-gray-500" />
            </div>
            <p className="text-gray-500 text-sm mb-1">Pending Orders</p>
            <p className="text-3xl font-display font-bold metallic-text">{stats.pendingOrders}</p>
          </motion.div>

          <motion.div
            className="bg-gray-950 rounded-xl p-6 border border-gray-800"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex items-center justify-between mb-4">
              <CheckCircle size={24} className="text-gray-400" />
              <TrendingUp size={20} className="text-gray-500" />
            </div>
            <p className="text-gray-500 text-sm mb-1">Completed Orders</p>
            <p className="text-3xl font-display font-bold metallic-text">{stats.completedOrders}</p>
          </motion.div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by order ID, customer name, or email..."
              className="w-full bg-gray-950 border border-gray-800 rounded-lg pl-12 pr-4 py-3 text-white focus:outline-none focus:border-gray-600"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter size={20} className="text-gray-500" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-gray-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="processing">Processing</option>
              <option value="shipped">Shipped</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>

        {/* Orders Table */}
        <div className="bg-gray-950 rounded-xl border border-gray-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-900">
                <tr>
                  <th className="text-left text-gray-400 font-medium py-4 px-6">Order ID</th>
                  <th className="text-left text-gray-400 font-medium py-4 px-6">Customer</th>
                  <th className="text-left text-gray-400 font-medium py-4 px-6">Items</th>
                  <th className="text-left text-gray-400 font-medium py-4 px-6">Total</th>
                  <th className="text-left text-gray-400 font-medium py-4 px-6">Status</th>
                  <th className="text-left text-gray-400 font-medium py-4 px-6">Payment</th>
                  <th className="text-left text-gray-400 font-medium py-4 px-6">Date</th>
                  <th className="text-left text-gray-400 font-medium py-4 px-6">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-12 text-gray-500">
                      <Package size={48} className="text-gray-700 mx-auto mb-4" />
                      <p>No orders found</p>
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((order) => (
                    <tr key={order.id} className="border-t border-gray-800 hover:bg-gray-900/50">
                      <td className="py-4 px-6">
                        <span className="text-white font-mono text-sm">#{order.id}</span>
                      </td>
                      <td className="py-4 px-6">
                        <div>
                          <p className="text-white font-medium">{order.customer.name}</p>
                          <p className="text-gray-500 text-sm">{order.customer.email}</p>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span className="text-gray-400">{order.items.length} items</span>
                      </td>
                      <td className="py-4 px-6">
                        <span className="text-white font-bold">${order.total.toFixed(2)}</span>
                      </td>
                      <td className="py-4 px-6">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${statusColors[order.status]}`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                          order.paymentStatus === 'completed'
                            ? 'bg-green-500/20 text-green-500'
                            : order.paymentStatus === 'pending'
                            ? 'bg-yellow-500/20 text-yellow-500'
                            : 'bg-red-500/20 text-red-500'
                        }`}>
                          {order.paymentStatus}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <span className="text-gray-400 text-sm">
                          {new Date(order.orderDate).toLocaleDateString()}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <motion.button
                          onClick={() => setSelectedOrder(order)}
                          className="p-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Eye size={16} />
                        </motion.button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Summary */}
        <div className="mt-6 text-center text-gray-500 text-sm">
          Showing {filteredOrders.length} of {orders.length} orders
        </div>
      </main>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <OrderDetailModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
          onUpdateStatus={updateOrderStatus}
        />
      )}
    </div>
  );
};

// Main Admin App Component
export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const auth = localStorage.getItem('adminAuthenticated');
    if (auth === 'true') {
      setIsAuthenticated(true);
    }
    setIsLoading(false);
  }, []);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('adminAuthenticated');
    setIsAuthenticated(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-gray-800 border-t-white rounded-full animate-spin" />
      </div>
    );
  }

  return isAuthenticated ? (
    <AdminDashboard onLogout={handleLogout} />
  ) : (
    <AdminLogin onLogin={handleLogin} />
  );
}
